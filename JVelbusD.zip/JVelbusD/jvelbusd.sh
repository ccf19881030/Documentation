#!bin/bash
lsusb
cd "$(dirname "$0")"
java -Djava.library.path=/usr/lib/jni -jar jvelbusd.jar
